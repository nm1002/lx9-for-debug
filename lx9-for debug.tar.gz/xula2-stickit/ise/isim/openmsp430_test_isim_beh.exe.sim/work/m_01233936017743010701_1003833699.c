/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/hp_guest/ti/xula2-stickit/ise/rtl/verilog/openmsp430/crypto/sponge_wrap.v";
static int ng1[] = {0, 0};
static int ng2[] = {7, 0};
static int ng3[] = {8, 0};
static int ng4[] = {1, 0};
static unsigned int ng5[] = {0U, 0U};
static unsigned int ng6[] = {1U, 0U};
static unsigned int ng7[] = {2U, 0U};
static unsigned int ng8[] = {3U, 0U};
static unsigned int ng9[] = {5U, 0U};
static unsigned int ng10[] = {4U, 0U};
static unsigned int ng11[] = {6U, 0U};
static unsigned int ng12[] = {7U, 0U};
static unsigned int ng13[] = {8U, 0U};
static unsigned int ng14[] = {9U, 0U};
static unsigned int ng15[] = {10U, 0U};
static unsigned int ng16[] = {11U, 0U};
static unsigned int ng17[] = {12U, 0U};
static unsigned int ng18[] = {15U, 15U};
static unsigned int ng19[] = {1U, 1U};
static const char *ng20 = "=== SpongeWrap parameters ===";
static const char *ng21 = "Rate:          %3d";
static const char *ng22 = "Security:      %3d";
static const char *ng23 = "Blocks in key: %3d";
static const char *ng24 = "=============================";



static int sp_reverse_bytes(char *t1, char *t2)
{
    char t8[8];
    char t14[8];
    char t25[8];
    char t28[8];
    char t29[8];
    char t30[8];
    char t38[8];
    char t40[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t26;
    char *t27;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t39;
    char *t41;
    char *t42;
    unsigned int t43;
    int t44;
    char *t45;
    unsigned int t46;
    int t47;
    int t48;
    char *t49;
    unsigned int t50;
    int t51;
    int t52;
    unsigned int t53;
    int t54;
    unsigned int t55;
    unsigned int t56;
    int t57;
    int t58;

LAB0:    t0 = 1;
    xsi_set_current_line(43, ng0);
    xsi_set_current_line(43, ng0);
    t3 = ((char*)((ng1)));
    t4 = (t1 + 8256);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 32);

LAB2:    t3 = (t1 + 8256);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t1 + 472);
    t7 = *((char **)t6);
    memset(t8, 0, 8);
    xsi_vlog_signed_less(t8, 32, t5, 32, t7, 32);
    t6 = (t8 + 4);
    t9 = *((unsigned int *)t6);
    t10 = (~(t9));
    t11 = *((unsigned int *)t8);
    t12 = (t11 & t10);
    t13 = (t12 != 0);
    if (t13 > 0)
        goto LAB3;

LAB4:    t0 = 0;

LAB1:    return t0;
LAB3:    xsi_set_current_line(44, ng0);
    t15 = (t1 + 9216);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    t18 = (t1 + 9216);
    t19 = (t18 + 72U);
    t20 = *((char **)t19);
    t21 = (t1 + 8256);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    t24 = ((char*)((ng2)));
    memset(t25, 0, 8);
    xsi_vlog_signed_add(t25, 32, t23, 32, t24, 32);
    t26 = ((char*)((ng3)));
    xsi_vlog_get_indexed_partselect(t14, 8, t17, ((int*)(t20)), 2, t25, 32, 1, t26, 32, 1, 0);
    t27 = (t1 + 9056);
    t31 = (t1 + 9056);
    t32 = (t31 + 72U);
    t33 = *((char **)t32);
    t34 = (t1 + 472);
    t35 = *((char **)t34);
    t34 = (t1 + 8256);
    t36 = (t34 + 56U);
    t37 = *((char **)t36);
    memset(t38, 0, 8);
    xsi_vlog_signed_minus(t38, 32, t35, 32, t37, 32);
    t39 = ((char*)((ng4)));
    memset(t40, 0, 8);
    xsi_vlog_signed_minus(t40, 32, t38, 32, t39, 32);
    t41 = ((char*)((ng3)));
    xsi_vlog_convert_indexed_partindices(t28, t29, t30, ((int*)(t33)), 2, t40, 32, 1, t41, 32, 1, 0);
    t42 = (t28 + 4);
    t43 = *((unsigned int *)t42);
    t44 = (!(t43));
    t45 = (t29 + 4);
    t46 = *((unsigned int *)t45);
    t47 = (!(t46));
    t48 = (t44 && t47);
    t49 = (t30 + 4);
    t50 = *((unsigned int *)t49);
    t51 = (!(t50));
    t52 = (t48 && t51);
    if (t52 == 1)
        goto LAB5;

LAB6:    xsi_set_current_line(43, ng0);
    t3 = (t1 + 8256);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = ((char*)((ng3)));
    memset(t8, 0, 8);
    xsi_vlog_signed_add(t8, 32, t5, 32, t6, 32);
    t7 = (t1 + 8256);
    xsi_vlogvar_assign_value(t7, t8, 0, 0, 32);
    goto LAB2;

LAB5:    t53 = *((unsigned int *)t30);
    t54 = (t53 + 0);
    t55 = *((unsigned int *)t28);
    t56 = *((unsigned int *)t29);
    t57 = (t55 - t56);
    t58 = (t57 + 1);
    xsi_vlogvar_assign_value(t27, t14, t54, *((unsigned int *)t29), t58);
    goto LAB6;

}

static void Always_65_0(char *t0)
{
    char t11[8];
    char t12[8];
    char t26[8];
    char t27[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    int t8;
    char *t9;
    char *t10;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    char *t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    char *t43;
    char *t44;

LAB0:    t1 = (t0 + 10128U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(65, ng0);
    t2 = (t0 + 13424);
    *((int *)t2) = 1;
    t3 = (t0 + 10160);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(66, ng0);
    t4 = (t0 + 8416);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);

LAB5:    t7 = ((char*)((ng5)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 4, t7, 4);
    if (t8 == 1)
        goto LAB6;

LAB7:    t2 = ((char*)((ng6)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 4, t2, 4);
    if (t8 == 1)
        goto LAB8;

LAB9:    t2 = ((char*)((ng7)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 4, t2, 4);
    if (t8 == 1)
        goto LAB10;

LAB11:    t2 = ((char*)((ng8)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 4, t2, 4);
    if (t8 == 1)
        goto LAB12;

LAB13:    t2 = ((char*)((ng10)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 4, t2, 4);
    if (t8 == 1)
        goto LAB14;

LAB15:    t2 = ((char*)((ng9)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 4, t2, 4);
    if (t8 == 1)
        goto LAB16;

LAB17:    t2 = ((char*)((ng11)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 4, t2, 4);
    if (t8 == 1)
        goto LAB18;

LAB19:    t2 = ((char*)((ng12)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 4, t2, 4);
    if (t8 == 1)
        goto LAB20;

LAB21:    t2 = ((char*)((ng13)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 4, t2, 4);
    if (t8 == 1)
        goto LAB22;

LAB23:    t2 = ((char*)((ng14)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 4, t2, 4);
    if (t8 == 1)
        goto LAB24;

LAB25:    t2 = ((char*)((ng15)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 4, t2, 4);
    if (t8 == 1)
        goto LAB26;

LAB27:    t2 = ((char*)((ng16)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 4, t2, 4);
    if (t8 == 1)
        goto LAB28;

LAB29:    t2 = ((char*)((ng17)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 4, t2, 4);
    if (t8 == 1)
        goto LAB30;

LAB31:
LAB33:
LAB32:    xsi_set_current_line(84, ng0);
    t2 = ((char*)((ng18)));
    t3 = (t0 + 8576);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);

LAB34:    goto LAB2;

LAB6:    xsi_set_current_line(67, ng0);
    t9 = ((char*)((ng6)));
    t10 = (t0 + 8576);
    xsi_vlogvar_assign_value(t10, t9, 0, 0, 4);
    goto LAB34;

LAB8:    xsi_set_current_line(68, ng0);
    t3 = (t0 + 4656U);
    t4 = *((char **)t3);
    memset(t12, 0, 8);
    t3 = (t4 + 4);
    t13 = *((unsigned int *)t3);
    t14 = (~(t13));
    t15 = *((unsigned int *)t4);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB35;

LAB36:    if (*((unsigned int *)t3) != 0)
        goto LAB37;

LAB38:    t7 = (t12 + 4);
    t18 = *((unsigned int *)t12);
    t19 = *((unsigned int *)t7);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB39;

LAB40:    t21 = *((unsigned int *)t12);
    t22 = (~(t21));
    t23 = *((unsigned int *)t7);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB41;

LAB42:    if (*((unsigned int *)t7) > 0)
        goto LAB43;

LAB44:    if (*((unsigned int *)t12) > 0)
        goto LAB45;

LAB46:    memcpy(t11, t10, 8);

LAB47:    t25 = (t0 + 8576);
    xsi_vlogvar_assign_value(t25, t11, 0, 0, 4);
    goto LAB34;

LAB10:    xsi_set_current_line(69, ng0);
    t3 = ((char*)((ng8)));
    t4 = (t0 + 8576);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 4);
    goto LAB34;

LAB12:    xsi_set_current_line(70, ng0);
    t3 = (t0 + 6096U);
    t4 = *((char **)t3);
    memset(t12, 0, 8);
    t3 = (t4 + 4);
    t13 = *((unsigned int *)t3);
    t14 = (~(t13));
    t15 = *((unsigned int *)t4);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB48;

LAB49:    if (*((unsigned int *)t3) != 0)
        goto LAB50;

LAB51:    t7 = (t12 + 4);
    t18 = *((unsigned int *)t12);
    t19 = *((unsigned int *)t7);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB52;

LAB53:    t21 = *((unsigned int *)t12);
    t22 = (~(t21));
    t23 = *((unsigned int *)t7);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB54;

LAB55:    if (*((unsigned int *)t7) > 0)
        goto LAB56;

LAB57:    if (*((unsigned int *)t12) > 0)
        goto LAB58;

LAB59:    memcpy(t11, t26, 8);

LAB60:    t44 = (t0 + 8576);
    xsi_vlogvar_assign_value(t44, t11, 0, 0, 4);
    goto LAB34;

LAB14:    xsi_set_current_line(72, ng0);
    t3 = (t0 + 4656U);
    t4 = *((char **)t3);
    memset(t12, 0, 8);
    t3 = (t4 + 4);
    t13 = *((unsigned int *)t3);
    t14 = (~(t13));
    t15 = *((unsigned int *)t4);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB74;

LAB75:    if (*((unsigned int *)t3) != 0)
        goto LAB76;

LAB77:    t7 = (t12 + 4);
    t18 = *((unsigned int *)t12);
    t19 = *((unsigned int *)t7);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB78;

LAB79:    t21 = *((unsigned int *)t12);
    t22 = (~(t21));
    t23 = *((unsigned int *)t7);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB80;

LAB81:    if (*((unsigned int *)t7) > 0)
        goto LAB82;

LAB83:    if (*((unsigned int *)t12) > 0)
        goto LAB84;

LAB85:    memcpy(t11, t10, 8);

LAB86:    t25 = (t0 + 8576);
    xsi_vlogvar_assign_value(t25, t11, 0, 0, 4);
    goto LAB34;

LAB16:    xsi_set_current_line(73, ng0);
    t3 = ((char*)((ng11)));
    t4 = (t0 + 8576);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 4);
    goto LAB34;

LAB18:    xsi_set_current_line(74, ng0);
    t3 = (t0 + 6096U);
    t4 = *((char **)t3);
    memset(t12, 0, 8);
    t3 = (t4 + 4);
    t13 = *((unsigned int *)t3);
    t14 = (~(t13));
    t15 = *((unsigned int *)t4);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB87;

LAB88:    if (*((unsigned int *)t3) != 0)
        goto LAB89;

LAB90:    t7 = (t12 + 4);
    t18 = *((unsigned int *)t12);
    t19 = *((unsigned int *)t7);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB91;

LAB92:    t21 = *((unsigned int *)t12);
    t22 = (~(t21));
    t23 = *((unsigned int *)t7);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB93;

LAB94:    if (*((unsigned int *)t7) > 0)
        goto LAB95;

LAB96:    if (*((unsigned int *)t12) > 0)
        goto LAB97;

LAB98:    memcpy(t11, t26, 8);

LAB99:    t44 = (t0 + 8576);
    xsi_vlogvar_assign_value(t44, t11, 0, 0, 4);
    goto LAB34;

LAB20:    xsi_set_current_line(76, ng0);
    t3 = (t0 + 4656U);
    t4 = *((char **)t3);
    memset(t12, 0, 8);
    t3 = (t4 + 4);
    t13 = *((unsigned int *)t3);
    t14 = (~(t13));
    t15 = *((unsigned int *)t4);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB113;

LAB114:    if (*((unsigned int *)t3) != 0)
        goto LAB115;

LAB116:    t7 = (t12 + 4);
    t18 = *((unsigned int *)t12);
    t19 = *((unsigned int *)t7);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB117;

LAB118:    t21 = *((unsigned int *)t12);
    t22 = (~(t21));
    t23 = *((unsigned int *)t7);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB119;

LAB120:    if (*((unsigned int *)t7) > 0)
        goto LAB121;

LAB122:    if (*((unsigned int *)t12) > 0)
        goto LAB123;

LAB124:    memcpy(t11, t10, 8);

LAB125:    t25 = (t0 + 8576);
    xsi_vlogvar_assign_value(t25, t11, 0, 0, 4);
    goto LAB34;

LAB22:    xsi_set_current_line(77, ng0);
    t3 = ((char*)((ng14)));
    t4 = (t0 + 8576);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 4);
    goto LAB34;

LAB24:    xsi_set_current_line(78, ng0);
    t3 = (t0 + 6096U);
    t4 = *((char **)t3);
    memset(t12, 0, 8);
    t3 = (t4 + 4);
    t13 = *((unsigned int *)t3);
    t14 = (~(t13));
    t15 = *((unsigned int *)t4);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB126;

LAB127:    if (*((unsigned int *)t3) != 0)
        goto LAB128;

LAB129:    t7 = (t12 + 4);
    t18 = *((unsigned int *)t12);
    t19 = *((unsigned int *)t7);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB130;

LAB131:    t21 = *((unsigned int *)t12);
    t22 = (~(t21));
    t23 = *((unsigned int *)t7);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB132;

LAB133:    if (*((unsigned int *)t7) > 0)
        goto LAB134;

LAB135:    if (*((unsigned int *)t12) > 0)
        goto LAB136;

LAB137:    memcpy(t11, t26, 8);

LAB138:    t44 = (t0 + 8576);
    xsi_vlogvar_assign_value(t44, t11, 0, 0, 4);
    goto LAB34;

LAB26:    xsi_set_current_line(80, ng0);
    t3 = (t0 + 4656U);
    t4 = *((char **)t3);
    memset(t12, 0, 8);
    t3 = (t4 + 4);
    t13 = *((unsigned int *)t3);
    t14 = (~(t13));
    t15 = *((unsigned int *)t4);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB152;

LAB153:    if (*((unsigned int *)t3) != 0)
        goto LAB154;

LAB155:    t7 = (t12 + 4);
    t18 = *((unsigned int *)t12);
    t19 = *((unsigned int *)t7);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB156;

LAB157:    t21 = *((unsigned int *)t12);
    t22 = (~(t21));
    t23 = *((unsigned int *)t7);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB158;

LAB159:    if (*((unsigned int *)t7) > 0)
        goto LAB160;

LAB161:    if (*((unsigned int *)t12) > 0)
        goto LAB162;

LAB163:    memcpy(t11, t10, 8);

LAB164:    t25 = (t0 + 8576);
    xsi_vlogvar_assign_value(t25, t11, 0, 0, 4);
    goto LAB34;

LAB28:    xsi_set_current_line(81, ng0);
    t3 = ((char*)((ng17)));
    t4 = (t0 + 8576);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 4);
    goto LAB34;

LAB30:    xsi_set_current_line(82, ng0);
    t3 = (t0 + 6096U);
    t4 = *((char **)t3);
    memset(t12, 0, 8);
    t3 = (t4 + 4);
    t13 = *((unsigned int *)t3);
    t14 = (~(t13));
    t15 = *((unsigned int *)t4);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB165;

LAB166:    if (*((unsigned int *)t3) != 0)
        goto LAB167;

LAB168:    t7 = (t12 + 4);
    t18 = *((unsigned int *)t12);
    t19 = *((unsigned int *)t7);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB169;

LAB170:    t21 = *((unsigned int *)t12);
    t22 = (~(t21));
    t23 = *((unsigned int *)t7);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB171;

LAB172:    if (*((unsigned int *)t7) > 0)
        goto LAB173;

LAB174:    if (*((unsigned int *)t12) > 0)
        goto LAB175;

LAB176:    memcpy(t11, t10, 8);

LAB177:    t25 = (t0 + 8576);
    xsi_vlogvar_assign_value(t25, t11, 0, 0, 4);
    goto LAB34;

LAB35:    *((unsigned int *)t12) = 1;
    goto LAB38;

LAB37:    t5 = (t12 + 4);
    *((unsigned int *)t12) = 1;
    *((unsigned int *)t5) = 1;
    goto LAB38;

LAB39:    t9 = ((char*)((ng7)));
    goto LAB40;

LAB41:    t10 = ((char*)((ng6)));
    goto LAB42;

LAB43:    xsi_vlog_unsigned_bit_combine(t11, 4, t9, 4, t10, 4);
    goto LAB47;

LAB45:    memcpy(t11, t9, 8);
    goto LAB47;

LAB48:    *((unsigned int *)t12) = 1;
    goto LAB51;

LAB50:    t5 = (t12 + 4);
    *((unsigned int *)t12) = 1;
    *((unsigned int *)t5) = 1;
    goto LAB51;

LAB52:    t9 = ((char*)((ng8)));
    goto LAB53;

LAB54:    t10 = (t0 + 5936U);
    t25 = *((char **)t10);
    memset(t27, 0, 8);
    t10 = (t25 + 4);
    t28 = *((unsigned int *)t10);
    t29 = (~(t28));
    t30 = *((unsigned int *)t25);
    t31 = (t30 & t29);
    t32 = (t31 & 1U);
    if (t32 != 0)
        goto LAB61;

LAB62:    if (*((unsigned int *)t10) != 0)
        goto LAB63;

LAB64:    t34 = (t27 + 4);
    t35 = *((unsigned int *)t27);
    t36 = *((unsigned int *)t34);
    t37 = (t35 || t36);
    if (t37 > 0)
        goto LAB65;

LAB66:    t39 = *((unsigned int *)t27);
    t40 = (~(t39));
    t41 = *((unsigned int *)t34);
    t42 = (t40 || t41);
    if (t42 > 0)
        goto LAB67;

LAB68:    if (*((unsigned int *)t34) > 0)
        goto LAB69;

LAB70:    if (*((unsigned int *)t27) > 0)
        goto LAB71;

LAB72:    memcpy(t26, t43, 8);

LAB73:    goto LAB55;

LAB56:    xsi_vlog_unsigned_bit_combine(t11, 4, t9, 4, t26, 4);
    goto LAB60;

LAB58:    memcpy(t11, t9, 8);
    goto LAB60;

LAB61:    *((unsigned int *)t27) = 1;
    goto LAB64;

LAB63:    t33 = (t27 + 4);
    *((unsigned int *)t27) = 1;
    *((unsigned int *)t33) = 1;
    goto LAB64;

LAB65:    t38 = ((char*)((ng9)));
    goto LAB66;

LAB67:    t43 = ((char*)((ng7)));
    goto LAB68;

LAB69:    xsi_vlog_unsigned_bit_combine(t26, 4, t38, 4, t43, 4);
    goto LAB73;

LAB71:    memcpy(t26, t38, 8);
    goto LAB73;

LAB74:    *((unsigned int *)t12) = 1;
    goto LAB77;

LAB76:    t5 = (t12 + 4);
    *((unsigned int *)t12) = 1;
    *((unsigned int *)t5) = 1;
    goto LAB77;

LAB78:    t9 = ((char*)((ng9)));
    goto LAB79;

LAB80:    t10 = ((char*)((ng10)));
    goto LAB81;

LAB82:    xsi_vlog_unsigned_bit_combine(t11, 4, t9, 4, t10, 4);
    goto LAB86;

LAB84:    memcpy(t11, t9, 8);
    goto LAB86;

LAB87:    *((unsigned int *)t12) = 1;
    goto LAB90;

LAB89:    t5 = (t12 + 4);
    *((unsigned int *)t12) = 1;
    *((unsigned int *)t5) = 1;
    goto LAB90;

LAB91:    t9 = ((char*)((ng11)));
    goto LAB92;

LAB93:    t10 = (t0 + 5296U);
    t25 = *((char **)t10);
    memset(t27, 0, 8);
    t10 = (t25 + 4);
    t28 = *((unsigned int *)t10);
    t29 = (~(t28));
    t30 = *((unsigned int *)t25);
    t31 = (t30 & t29);
    t32 = (t31 & 1U);
    if (t32 != 0)
        goto LAB100;

LAB101:    if (*((unsigned int *)t10) != 0)
        goto LAB102;

LAB103:    t34 = (t27 + 4);
    t35 = *((unsigned int *)t27);
    t36 = *((unsigned int *)t34);
    t37 = (t35 || t36);
    if (t37 > 0)
        goto LAB104;

LAB105:    t39 = *((unsigned int *)t27);
    t40 = (~(t39));
    t41 = *((unsigned int *)t34);
    t42 = (t40 || t41);
    if (t42 > 0)
        goto LAB106;

LAB107:    if (*((unsigned int *)t34) > 0)
        goto LAB108;

LAB109:    if (*((unsigned int *)t27) > 0)
        goto LAB110;

LAB111:    memcpy(t26, t43, 8);

LAB112:    goto LAB94;

LAB95:    xsi_vlog_unsigned_bit_combine(t11, 4, t9, 4, t26, 4);
    goto LAB99;

LAB97:    memcpy(t11, t9, 8);
    goto LAB99;

LAB100:    *((unsigned int *)t27) = 1;
    goto LAB103;

LAB102:    t33 = (t27 + 4);
    *((unsigned int *)t27) = 1;
    *((unsigned int *)t33) = 1;
    goto LAB103;

LAB104:    t38 = ((char*)((ng12)));
    goto LAB105;

LAB106:    t43 = ((char*)((ng10)));
    goto LAB107;

LAB108:    xsi_vlog_unsigned_bit_combine(t26, 4, t38, 4, t43, 4);
    goto LAB112;

LAB110:    memcpy(t26, t38, 8);
    goto LAB112;

LAB113:    *((unsigned int *)t12) = 1;
    goto LAB116;

LAB115:    t5 = (t12 + 4);
    *((unsigned int *)t12) = 1;
    *((unsigned int *)t5) = 1;
    goto LAB116;

LAB117:    t9 = ((char*)((ng13)));
    goto LAB118;

LAB119:    t10 = ((char*)((ng12)));
    goto LAB120;

LAB121:    xsi_vlog_unsigned_bit_combine(t11, 4, t9, 4, t10, 4);
    goto LAB125;

LAB123:    memcpy(t11, t9, 8);
    goto LAB125;

LAB126:    *((unsigned int *)t12) = 1;
    goto LAB129;

LAB128:    t5 = (t12 + 4);
    *((unsigned int *)t12) = 1;
    *((unsigned int *)t5) = 1;
    goto LAB129;

LAB130:    t9 = ((char*)((ng14)));
    goto LAB131;

LAB132:    t10 = (t0 + 5296U);
    t25 = *((char **)t10);
    memset(t27, 0, 8);
    t10 = (t25 + 4);
    t28 = *((unsigned int *)t10);
    t29 = (~(t28));
    t30 = *((unsigned int *)t25);
    t31 = (t30 & t29);
    t32 = (t31 & 1U);
    if (t32 != 0)
        goto LAB139;

LAB140:    if (*((unsigned int *)t10) != 0)
        goto LAB141;

LAB142:    t34 = (t27 + 4);
    t35 = *((unsigned int *)t27);
    t36 = *((unsigned int *)t34);
    t37 = (t35 || t36);
    if (t37 > 0)
        goto LAB143;

LAB144:    t39 = *((unsigned int *)t27);
    t40 = (~(t39));
    t41 = *((unsigned int *)t34);
    t42 = (t40 || t41);
    if (t42 > 0)
        goto LAB145;

LAB146:    if (*((unsigned int *)t34) > 0)
        goto LAB147;

LAB148:    if (*((unsigned int *)t27) > 0)
        goto LAB149;

LAB150:    memcpy(t26, t43, 8);

LAB151:    goto LAB133;

LAB134:    xsi_vlog_unsigned_bit_combine(t11, 4, t9, 4, t26, 4);
    goto LAB138;

LAB136:    memcpy(t11, t9, 8);
    goto LAB138;

LAB139:    *((unsigned int *)t27) = 1;
    goto LAB142;

LAB141:    t33 = (t27 + 4);
    *((unsigned int *)t27) = 1;
    *((unsigned int *)t33) = 1;
    goto LAB142;

LAB143:    t38 = ((char*)((ng15)));
    goto LAB144;

LAB145:    t43 = ((char*)((ng12)));
    goto LAB146;

LAB147:    xsi_vlog_unsigned_bit_combine(t26, 4, t38, 4, t43, 4);
    goto LAB151;

LAB149:    memcpy(t26, t38, 8);
    goto LAB151;

LAB152:    *((unsigned int *)t12) = 1;
    goto LAB155;

LAB154:    t5 = (t12 + 4);
    *((unsigned int *)t12) = 1;
    *((unsigned int *)t5) = 1;
    goto LAB155;

LAB156:    t9 = ((char*)((ng16)));
    goto LAB157;

LAB158:    t10 = ((char*)((ng15)));
    goto LAB159;

LAB160:    xsi_vlog_unsigned_bit_combine(t11, 4, t9, 4, t10, 4);
    goto LAB164;

LAB162:    memcpy(t11, t9, 8);
    goto LAB164;

LAB165:    *((unsigned int *)t12) = 1;
    goto LAB168;

LAB167:    t5 = (t12 + 4);
    *((unsigned int *)t12) = 1;
    *((unsigned int *)t5) = 1;
    goto LAB168;

LAB169:    t9 = ((char*)((ng17)));
    goto LAB170;

LAB171:    t10 = ((char*)((ng15)));
    goto LAB172;

LAB173:    xsi_vlog_unsigned_bit_combine(t11, 4, t9, 4, t10, 4);
    goto LAB177;

LAB175:    memcpy(t11, t9, 8);
    goto LAB177;

}

static void Always_87_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;

LAB0:    t1 = (t0 + 10376U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(87, ng0);
    t2 = (t0 + 13440);
    *((int *)t2) = 1;
    t3 = (t0 + 10408);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(88, ng0);
    t4 = (t0 + 4496U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB5;

LAB6:    xsi_set_current_line(91, ng0);
    t2 = (t0 + 8576);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 8416);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 4, 0LL);

LAB7:    goto LAB2;

LAB5:    xsi_set_current_line(89, ng0);
    t11 = ((char*)((ng5)));
    t12 = (t0 + 8416);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 4, 0LL);
    goto LAB7;

}

static void Always_94_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;

LAB0:    t1 = (t0 + 10624U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(94, ng0);
    t2 = (t0 + 13456);
    *((int *)t2) = 1;
    t3 = (t0 + 10656);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(95, ng0);

LAB5:    xsi_set_current_line(96, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t0 + 7456);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(97, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 7616);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(98, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 7776);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(99, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 7936);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(100, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 7296);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(101, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 8096);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(103, ng0);
    t2 = (t0 + 8576);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);

LAB6:    t5 = ((char*)((ng5)));
    t6 = xsi_vlog_unsigned_case_compare(t4, 4, t5, 4);
    if (t6 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng6)));
    t6 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t6 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng7)));
    t6 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t6 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng8)));
    t6 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t6 == 1)
        goto LAB13;

LAB14:    t2 = ((char*)((ng10)));
    t6 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t6 == 1)
        goto LAB15;

LAB16:    t2 = ((char*)((ng9)));
    t6 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t6 == 1)
        goto LAB17;

LAB18:    t2 = ((char*)((ng11)));
    t6 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t6 == 1)
        goto LAB19;

LAB20:    t2 = ((char*)((ng12)));
    t6 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t6 == 1)
        goto LAB21;

LAB22:    t2 = ((char*)((ng13)));
    t6 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t6 == 1)
        goto LAB23;

LAB24:    t2 = ((char*)((ng14)));
    t6 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t6 == 1)
        goto LAB25;

LAB26:    t2 = ((char*)((ng15)));
    t6 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t6 == 1)
        goto LAB27;

LAB28:    t2 = ((char*)((ng16)));
    t6 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t6 == 1)
        goto LAB29;

LAB30:    t2 = ((char*)((ng17)));
    t6 = xsi_vlog_unsigned_case_compare(t4, 4, t2, 4);
    if (t6 == 1)
        goto LAB31;

LAB32:
LAB33:    goto LAB2;

LAB7:    xsi_set_current_line(105, ng0);

LAB34:    goto LAB33;

LAB9:    xsi_set_current_line(109, ng0);

LAB35:    goto LAB33;

LAB11:    xsi_set_current_line(113, ng0);

LAB36:    xsi_set_current_line(114, ng0);
    t3 = ((char*)((ng4)));
    t5 = (t0 + 7456);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 1);
    xsi_set_current_line(115, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 7936);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB33;

LAB13:    xsi_set_current_line(119, ng0);

LAB37:    goto LAB33;

LAB15:    xsi_set_current_line(123, ng0);

LAB38:    goto LAB33;

LAB17:    xsi_set_current_line(127, ng0);

LAB39:    xsi_set_current_line(128, ng0);
    t3 = ((char*)((ng4)));
    t5 = (t0 + 7936);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 1);
    goto LAB33;

LAB19:    xsi_set_current_line(132, ng0);

LAB40:    goto LAB33;

LAB21:    xsi_set_current_line(136, ng0);

LAB41:    goto LAB33;

LAB23:    xsi_set_current_line(140, ng0);

LAB42:    xsi_set_current_line(141, ng0);
    t3 = ((char*)((ng4)));
    t5 = (t0 + 7936);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 1);
    xsi_set_current_line(142, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 7296);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(143, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 8096);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(144, ng0);
    t2 = (t0 + 4816U);
    t3 = *((char **)t2);
    t2 = (t0 + 7616);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 1);
    goto LAB33;

LAB25:    xsi_set_current_line(148, ng0);

LAB43:    goto LAB33;

LAB27:    xsi_set_current_line(152, ng0);

LAB44:    goto LAB33;

LAB29:    xsi_set_current_line(156, ng0);

LAB45:    xsi_set_current_line(157, ng0);
    t3 = ((char*)((ng4)));
    t5 = (t0 + 7936);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 1);
    xsi_set_current_line(158, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 7776);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(159, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 7296);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB33;

LAB31:    xsi_set_current_line(163, ng0);

LAB46:    goto LAB33;

}

static void NetDecl_170_3(char *t0)
{
    char t6[8];
    char t26[8];
    char t42[8];
    char t74[8];
    char t90[8];
    char t122[8];
    char t138[8];
    char t170[8];
    char t186[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    char *t41;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    char *t46;
    char *t47;
    char *t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    char *t56;
    char *t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    char *t70;
    char *t71;
    char *t72;
    char *t73;
    char *t75;
    char *t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    char *t89;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    char *t94;
    char *t95;
    char *t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    char *t104;
    char *t105;
    unsigned int t106;
    unsigned int t107;
    unsigned int t108;
    int t109;
    unsigned int t110;
    unsigned int t111;
    unsigned int t112;
    int t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;
    char *t118;
    char *t119;
    char *t120;
    char *t121;
    char *t123;
    char *t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    unsigned int t129;
    unsigned int t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    unsigned int t134;
    unsigned int t135;
    unsigned int t136;
    char *t137;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    char *t142;
    char *t143;
    char *t144;
    unsigned int t145;
    unsigned int t146;
    unsigned int t147;
    unsigned int t148;
    unsigned int t149;
    unsigned int t150;
    unsigned int t151;
    char *t152;
    char *t153;
    unsigned int t154;
    unsigned int t155;
    unsigned int t156;
    int t157;
    unsigned int t158;
    unsigned int t159;
    unsigned int t160;
    int t161;
    unsigned int t162;
    unsigned int t163;
    unsigned int t164;
    unsigned int t165;
    char *t166;
    char *t167;
    char *t168;
    char *t169;
    char *t171;
    char *t172;
    unsigned int t173;
    unsigned int t174;
    unsigned int t175;
    unsigned int t176;
    unsigned int t177;
    unsigned int t178;
    unsigned int t179;
    unsigned int t180;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    unsigned int t184;
    char *t185;
    unsigned int t187;
    unsigned int t188;
    unsigned int t189;
    char *t190;
    char *t191;
    char *t192;
    unsigned int t193;
    unsigned int t194;
    unsigned int t195;
    unsigned int t196;
    unsigned int t197;
    unsigned int t198;
    unsigned int t199;
    char *t200;
    char *t201;
    unsigned int t202;
    unsigned int t203;
    unsigned int t204;
    int t205;
    unsigned int t206;
    unsigned int t207;
    unsigned int t208;
    int t209;
    unsigned int t210;
    unsigned int t211;
    unsigned int t212;
    unsigned int t213;
    char *t214;
    char *t215;
    char *t216;
    char *t217;
    char *t218;
    unsigned int t219;
    unsigned int t220;
    char *t221;
    unsigned int t222;
    unsigned int t223;
    char *t224;
    unsigned int t225;
    unsigned int t226;
    char *t227;

LAB0:    t1 = (t0 + 10872U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(170, ng0);
    t2 = (t0 + 8416);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng5)));
    memset(t6, 0, 8);
    t7 = (t4 + 4);
    t8 = (t5 + 4);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t5);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB7;

LAB4:    if (t18 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t6) = 1;

LAB7:    t22 = (t0 + 8416);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    t25 = ((char*)((ng6)));
    memset(t26, 0, 8);
    t27 = (t24 + 4);
    t28 = (t25 + 4);
    t29 = *((unsigned int *)t24);
    t30 = *((unsigned int *)t25);
    t31 = (t29 ^ t30);
    t32 = *((unsigned int *)t27);
    t33 = *((unsigned int *)t28);
    t34 = (t32 ^ t33);
    t35 = (t31 | t34);
    t36 = *((unsigned int *)t27);
    t37 = *((unsigned int *)t28);
    t38 = (t36 | t37);
    t39 = (~(t38));
    t40 = (t35 & t39);
    if (t40 != 0)
        goto LAB11;

LAB8:    if (t38 != 0)
        goto LAB10;

LAB9:    *((unsigned int *)t26) = 1;

LAB11:    t43 = *((unsigned int *)t6);
    t44 = *((unsigned int *)t26);
    t45 = (t43 | t44);
    *((unsigned int *)t42) = t45;
    t46 = (t6 + 4);
    t47 = (t26 + 4);
    t48 = (t42 + 4);
    t49 = *((unsigned int *)t46);
    t50 = *((unsigned int *)t47);
    t51 = (t49 | t50);
    *((unsigned int *)t48) = t51;
    t52 = *((unsigned int *)t48);
    t53 = (t52 != 0);
    if (t53 == 1)
        goto LAB12;

LAB13:
LAB14:    t70 = (t0 + 8416);
    t71 = (t70 + 56U);
    t72 = *((char **)t71);
    t73 = ((char*)((ng10)));
    memset(t74, 0, 8);
    t75 = (t72 + 4);
    t76 = (t73 + 4);
    t77 = *((unsigned int *)t72);
    t78 = *((unsigned int *)t73);
    t79 = (t77 ^ t78);
    t80 = *((unsigned int *)t75);
    t81 = *((unsigned int *)t76);
    t82 = (t80 ^ t81);
    t83 = (t79 | t82);
    t84 = *((unsigned int *)t75);
    t85 = *((unsigned int *)t76);
    t86 = (t84 | t85);
    t87 = (~(t86));
    t88 = (t83 & t87);
    if (t88 != 0)
        goto LAB18;

LAB15:    if (t86 != 0)
        goto LAB17;

LAB16:    *((unsigned int *)t74) = 1;

LAB18:    t91 = *((unsigned int *)t42);
    t92 = *((unsigned int *)t74);
    t93 = (t91 | t92);
    *((unsigned int *)t90) = t93;
    t94 = (t42 + 4);
    t95 = (t74 + 4);
    t96 = (t90 + 4);
    t97 = *((unsigned int *)t94);
    t98 = *((unsigned int *)t95);
    t99 = (t97 | t98);
    *((unsigned int *)t96) = t99;
    t100 = *((unsigned int *)t96);
    t101 = (t100 != 0);
    if (t101 == 1)
        goto LAB19;

LAB20:
LAB21:    t118 = (t0 + 8416);
    t119 = (t118 + 56U);
    t120 = *((char **)t119);
    t121 = ((char*)((ng12)));
    memset(t122, 0, 8);
    t123 = (t120 + 4);
    t124 = (t121 + 4);
    t125 = *((unsigned int *)t120);
    t126 = *((unsigned int *)t121);
    t127 = (t125 ^ t126);
    t128 = *((unsigned int *)t123);
    t129 = *((unsigned int *)t124);
    t130 = (t128 ^ t129);
    t131 = (t127 | t130);
    t132 = *((unsigned int *)t123);
    t133 = *((unsigned int *)t124);
    t134 = (t132 | t133);
    t135 = (~(t134));
    t136 = (t131 & t135);
    if (t136 != 0)
        goto LAB25;

LAB22:    if (t134 != 0)
        goto LAB24;

LAB23:    *((unsigned int *)t122) = 1;

LAB25:    t139 = *((unsigned int *)t90);
    t140 = *((unsigned int *)t122);
    t141 = (t139 | t140);
    *((unsigned int *)t138) = t141;
    t142 = (t90 + 4);
    t143 = (t122 + 4);
    t144 = (t138 + 4);
    t145 = *((unsigned int *)t142);
    t146 = *((unsigned int *)t143);
    t147 = (t145 | t146);
    *((unsigned int *)t144) = t147;
    t148 = *((unsigned int *)t144);
    t149 = (t148 != 0);
    if (t149 == 1)
        goto LAB26;

LAB27:
LAB28:    t166 = (t0 + 8416);
    t167 = (t166 + 56U);
    t168 = *((char **)t167);
    t169 = ((char*)((ng15)));
    memset(t170, 0, 8);
    t171 = (t168 + 4);
    t172 = (t169 + 4);
    t173 = *((unsigned int *)t168);
    t174 = *((unsigned int *)t169);
    t175 = (t173 ^ t174);
    t176 = *((unsigned int *)t171);
    t177 = *((unsigned int *)t172);
    t178 = (t176 ^ t177);
    t179 = (t175 | t178);
    t180 = *((unsigned int *)t171);
    t181 = *((unsigned int *)t172);
    t182 = (t180 | t181);
    t183 = (~(t182));
    t184 = (t179 & t183);
    if (t184 != 0)
        goto LAB32;

LAB29:    if (t182 != 0)
        goto LAB31;

LAB30:    *((unsigned int *)t170) = 1;

LAB32:    t187 = *((unsigned int *)t138);
    t188 = *((unsigned int *)t170);
    t189 = (t187 | t188);
    *((unsigned int *)t186) = t189;
    t190 = (t138 + 4);
    t191 = (t170 + 4);
    t192 = (t186 + 4);
    t193 = *((unsigned int *)t190);
    t194 = *((unsigned int *)t191);
    t195 = (t193 | t194);
    *((unsigned int *)t192) = t195;
    t196 = *((unsigned int *)t192);
    t197 = (t196 != 0);
    if (t197 == 1)
        goto LAB33;

LAB34:
LAB35:    t214 = (t0 + 13680);
    t215 = (t214 + 56U);
    t216 = *((char **)t215);
    t217 = (t216 + 56U);
    t218 = *((char **)t217);
    memset(t218, 0, 8);
    t219 = 1U;
    t220 = t219;
    t221 = (t186 + 4);
    t222 = *((unsigned int *)t186);
    t219 = (t219 & t222);
    t223 = *((unsigned int *)t221);
    t220 = (t220 & t223);
    t224 = (t218 + 4);
    t225 = *((unsigned int *)t218);
    *((unsigned int *)t218) = (t225 | t219);
    t226 = *((unsigned int *)t224);
    *((unsigned int *)t224) = (t226 | t220);
    xsi_driver_vfirst_trans(t214, 0, 0U);
    t227 = (t0 + 13472);
    *((int *)t227) = 1;

LAB1:    return;
LAB6:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB7;

LAB10:    t41 = (t26 + 4);
    *((unsigned int *)t26) = 1;
    *((unsigned int *)t41) = 1;
    goto LAB11;

LAB12:    t54 = *((unsigned int *)t42);
    t55 = *((unsigned int *)t48);
    *((unsigned int *)t42) = (t54 | t55);
    t56 = (t6 + 4);
    t57 = (t26 + 4);
    t58 = *((unsigned int *)t56);
    t59 = (~(t58));
    t60 = *((unsigned int *)t6);
    t61 = (t60 & t59);
    t62 = *((unsigned int *)t57);
    t63 = (~(t62));
    t64 = *((unsigned int *)t26);
    t65 = (t64 & t63);
    t66 = (~(t61));
    t67 = (~(t65));
    t68 = *((unsigned int *)t48);
    *((unsigned int *)t48) = (t68 & t66);
    t69 = *((unsigned int *)t48);
    *((unsigned int *)t48) = (t69 & t67);
    goto LAB14;

LAB17:    t89 = (t74 + 4);
    *((unsigned int *)t74) = 1;
    *((unsigned int *)t89) = 1;
    goto LAB18;

LAB19:    t102 = *((unsigned int *)t90);
    t103 = *((unsigned int *)t96);
    *((unsigned int *)t90) = (t102 | t103);
    t104 = (t42 + 4);
    t105 = (t74 + 4);
    t106 = *((unsigned int *)t104);
    t107 = (~(t106));
    t108 = *((unsigned int *)t42);
    t109 = (t108 & t107);
    t110 = *((unsigned int *)t105);
    t111 = (~(t110));
    t112 = *((unsigned int *)t74);
    t113 = (t112 & t111);
    t114 = (~(t109));
    t115 = (~(t113));
    t116 = *((unsigned int *)t96);
    *((unsigned int *)t96) = (t116 & t114);
    t117 = *((unsigned int *)t96);
    *((unsigned int *)t96) = (t117 & t115);
    goto LAB21;

LAB24:    t137 = (t122 + 4);
    *((unsigned int *)t122) = 1;
    *((unsigned int *)t137) = 1;
    goto LAB25;

LAB26:    t150 = *((unsigned int *)t138);
    t151 = *((unsigned int *)t144);
    *((unsigned int *)t138) = (t150 | t151);
    t152 = (t90 + 4);
    t153 = (t122 + 4);
    t154 = *((unsigned int *)t152);
    t155 = (~(t154));
    t156 = *((unsigned int *)t90);
    t157 = (t156 & t155);
    t158 = *((unsigned int *)t153);
    t159 = (~(t158));
    t160 = *((unsigned int *)t122);
    t161 = (t160 & t159);
    t162 = (~(t157));
    t163 = (~(t161));
    t164 = *((unsigned int *)t144);
    *((unsigned int *)t144) = (t164 & t162);
    t165 = *((unsigned int *)t144);
    *((unsigned int *)t144) = (t165 & t163);
    goto LAB28;

LAB31:    t185 = (t170 + 4);
    *((unsigned int *)t170) = 1;
    *((unsigned int *)t185) = 1;
    goto LAB32;

LAB33:    t198 = *((unsigned int *)t186);
    t199 = *((unsigned int *)t192);
    *((unsigned int *)t186) = (t198 | t199);
    t200 = (t138 + 4);
    t201 = (t170 + 4);
    t202 = *((unsigned int *)t200);
    t203 = (~(t202));
    t204 = *((unsigned int *)t138);
    t205 = (t204 & t203);
    t206 = *((unsigned int *)t201);
    t207 = (~(t206));
    t208 = *((unsigned int *)t170);
    t209 = (t208 & t207);
    t210 = (~(t205));
    t211 = (~(t209));
    t212 = *((unsigned int *)t192);
    *((unsigned int *)t192) = (t212 & t210);
    t213 = *((unsigned int *)t192);
    *((unsigned int *)t192) = (t213 & t211);
    goto LAB35;

}

static void Cont_176_4(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;

LAB0:    t1 = (t0 + 11120U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(176, ng0);
    t2 = (t0 + 6416U);
    t4 = *((char **)t2);
    memset(t3, 0, 8);
    t2 = (t4 + 4);
    t5 = *((unsigned int *)t2);
    t6 = (~(t5));
    t7 = *((unsigned int *)t4);
    t8 = (t7 & t6);
    t9 = (t8 & 1U);
    if (t9 != 0)
        goto LAB7;

LAB5:    if (*((unsigned int *)t2) == 0)
        goto LAB4;

LAB6:    t10 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t10) = 1;

LAB7:    t11 = (t0 + 13744);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memset(t15, 0, 8);
    t16 = 1U;
    t17 = t16;
    t18 = (t3 + 4);
    t19 = *((unsigned int *)t3);
    t16 = (t16 & t19);
    t20 = *((unsigned int *)t18);
    t17 = (t17 & t20);
    t21 = (t15 + 4);
    t22 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t22 | t16);
    t23 = *((unsigned int *)t21);
    *((unsigned int *)t21) = (t23 | t17);
    xsi_driver_vfirst_trans(t11, 0, 0);
    t24 = (t0 + 13488);
    *((int *)t24) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t3) = 1;
    goto LAB7;

}

static void Always_181_5(char *t0)
{
    char t15[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t16;

LAB0:    t1 = (t0 + 11368U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(181, ng0);
    t2 = (t0 + 13504);
    *((int *)t2) = 1;
    t3 = (t0 + 11400);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(182, ng0);
    t4 = (t0 + 4496U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB5;

LAB6:    xsi_set_current_line(184, ng0);
    t2 = (t0 + 7456);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 4);
    t6 = *((unsigned int *)t5);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB8;

LAB9:
LAB10:
LAB7:    goto LAB2;

LAB5:    xsi_set_current_line(183, ng0);
    t11 = ((char*)((ng1)));
    t12 = (t0 + 8736);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 3, 0LL);
    goto LAB7;

LAB8:    xsi_set_current_line(185, ng0);
    t11 = (t0 + 8736);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = ((char*)((ng4)));
    memset(t15, 0, 8);
    xsi_vlog_unsigned_add(t15, 32, t13, 3, t14, 32);
    t16 = (t0 + 8736);
    xsi_vlogvar_wait_assign_value(t16, t15, 0, 0, 3, 0LL);
    goto LAB10;

}

static void Cont_187_6(char *t0)
{
    char t7[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;

LAB0:    t1 = (t0 + 11616U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(187, ng0);
    t2 = (t0 + 8736);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 1152);
    t6 = *((char **)t5);
    memset(t7, 0, 8);
    t5 = (t4 + 4);
    t8 = (t6 + 4);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t6);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t5);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t5);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB7;

LAB4:    if (t18 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t7) = 1;

LAB7:    t22 = (t0 + 13808);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    memset(t26, 0, 8);
    t27 = 1U;
    t28 = t27;
    t29 = (t7 + 4);
    t30 = *((unsigned int *)t7);
    t27 = (t27 & t30);
    t31 = *((unsigned int *)t29);
    t28 = (t28 & t31);
    t32 = (t26 + 4);
    t33 = *((unsigned int *)t26);
    *((unsigned int *)t26) = (t33 | t27);
    t34 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t34 | t28);
    xsi_driver_vfirst_trans(t22, 0, 0);
    t35 = (t0 + 13520);
    *((int *)t35) = 1;

LAB1:    return;
LAB6:    t21 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB7;

}

static void Always_192_7(char *t0)
{
    char t14[8];
    char t15[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    int t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t16;
    char *t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    char *t31;
    unsigned int t32;

LAB0:    t1 = (t0 + 11864U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(192, ng0);
    t2 = (t0 + 13536);
    *((int *)t2) = 1;
    t3 = (t0 + 11896);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(193, ng0);
    t4 = (t0 + 8576);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);

LAB5:    t7 = ((char*)((ng7)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 4, t7, 4);
    if (t8 == 1)
        goto LAB6;

LAB7:    t2 = ((char*)((ng9)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 4, t2, 4);
    if (t8 == 1)
        goto LAB8;

LAB9:    t2 = ((char*)((ng13)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 4, t2, 4);
    if (t8 == 1)
        goto LAB10;

LAB11:
LAB13:
LAB12:    xsi_set_current_line(197, ng0);
    t2 = ((char*)((ng19)));
    t3 = (t0 + 8896);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB14:    goto LAB2;

LAB6:    xsi_set_current_line(194, ng0);
    t9 = (t0 + 8736);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = (t0 + 1152);
    t13 = *((char **)t12);
    t12 = ((char*)((ng4)));
    memset(t14, 0, 8);
    xsi_vlog_unsigned_minus(t14, 32, t13, 32, t12, 32);
    memset(t15, 0, 8);
    t16 = (t11 + 4);
    t17 = (t14 + 4);
    t18 = *((unsigned int *)t11);
    t19 = *((unsigned int *)t14);
    t20 = (t18 ^ t19);
    t21 = *((unsigned int *)t16);
    t22 = *((unsigned int *)t17);
    t23 = (t21 ^ t22);
    t24 = (t20 | t23);
    t25 = *((unsigned int *)t16);
    t26 = *((unsigned int *)t17);
    t27 = (t25 | t26);
    t28 = (~(t27));
    t29 = (t24 & t28);
    if (t29 != 0)
        goto LAB16;

LAB15:    if (t27 != 0)
        goto LAB17;

LAB18:    t31 = (t0 + 8896);
    xsi_vlogvar_assign_value(t31, t15, 0, 0, 1);
    goto LAB14;

LAB8:    xsi_set_current_line(195, ng0);
    t3 = (t0 + 5296U);
    t4 = *((char **)t3);
    t3 = (t0 + 8896);
    xsi_vlogvar_assign_value(t3, t4, 0, 0, 1);
    goto LAB14;

LAB10:    xsi_set_current_line(196, ng0);
    t3 = (t0 + 5296U);
    t4 = *((char **)t3);
    memset(t14, 0, 8);
    t3 = (t4 + 4);
    t18 = *((unsigned int *)t3);
    t19 = (~(t18));
    t20 = *((unsigned int *)t4);
    t21 = (t20 & t19);
    t22 = (t21 & 1U);
    if (t22 != 0)
        goto LAB22;

LAB20:    if (*((unsigned int *)t3) == 0)
        goto LAB19;

LAB21:    t5 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t5) = 1;

LAB22:    t7 = (t14 + 4);
    t9 = (t4 + 4);
    t23 = *((unsigned int *)t4);
    t24 = (~(t23));
    *((unsigned int *)t14) = t24;
    *((unsigned int *)t7) = 0;
    if (*((unsigned int *)t9) != 0)
        goto LAB24;

LAB23:    t29 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t29 & 1U);
    t32 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t32 & 1U);
    t10 = (t0 + 8896);
    xsi_vlogvar_assign_value(t10, t14, 0, 0, 1);
    goto LAB14;

LAB16:    *((unsigned int *)t15) = 1;
    goto LAB18;

LAB17:    t30 = (t15 + 4);
    *((unsigned int *)t15) = 1;
    *((unsigned int *)t30) = 1;
    goto LAB18;

LAB19:    *((unsigned int *)t14) = 1;
    goto LAB22;

LAB24:    t25 = *((unsigned int *)t14);
    t26 = *((unsigned int *)t9);
    *((unsigned int *)t14) = (t25 | t26);
    t27 = *((unsigned int *)t7);
    t28 = *((unsigned int *)t9);
    *((unsigned int *)t7) = (t27 | t28);
    goto LAB23;

}

static void NetDecl_201_8(char *t0)
{
    char t3[8];
    char t12[8];
    char t29[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    int t25;
    char *t26;
    char *t27;
    char *t28;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    unsigned int t38;
    unsigned int t39;
    char *t40;
    unsigned int t41;
    unsigned int t42;
    char *t43;
    unsigned int t44;
    unsigned int t45;
    char *t46;

LAB0:    t1 = (t0 + 12112U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(201, ng0);
    t2 = (t0 + 5456U);
    t4 = *((char **)t2);
    t2 = (t0 + 5416U);
    t5 = (t2 + 72U);
    t6 = *((char **)t5);
    t7 = (t0 + 8736);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t0 + 472);
    t11 = *((char **)t10);
    memset(t12, 0, 8);
    xsi_vlog_unsigned_multiply(t12, 32, t9, 3, t11, 32);
    t10 = (t0 + 472);
    t13 = *((char **)t10);
    xsi_vlog_get_indexed_partselect(t3, 16, t4, ((int*)(t6)), 2, t12, 32, 2, t13, 32, 1, 1);
    t10 = (t0 + 11920);
    t14 = (t0 + 3704);
    t15 = xsi_create_subprogram_invocation(t10, 0, t0, t14, 0, 0);
    t16 = (t0 + 9216);
    xsi_vlogvar_assign_value(t16, t3, 0, 0, 16);

LAB4:    t17 = (t0 + 12016);
    t18 = *((char **)t17);
    t19 = (t18 + 80U);
    t20 = *((char **)t19);
    t21 = (t20 + 272U);
    t22 = *((char **)t21);
    t23 = (t22 + 0U);
    t24 = *((char **)t23);
    t25 = ((int  (*)(char *, char *))t24)(t0, t18);
    if (t25 != 0)
        goto LAB6;

LAB5:    t18 = (t0 + 12016);
    t26 = *((char **)t18);
    t18 = (t0 + 9056);
    t27 = (t18 + 56U);
    t28 = *((char **)t27);
    memcpy(t29, t28, 8);
    t30 = (t0 + 3704);
    t31 = (t0 + 11920);
    t32 = 0;
    xsi_delete_subprogram_invocation(t30, t26, t0, t31, t32);
    t33 = (t0 + 13872);
    t34 = (t33 + 56U);
    t35 = *((char **)t34);
    t36 = (t35 + 56U);
    t37 = *((char **)t36);
    memset(t37, 0, 8);
    t38 = 65535U;
    t39 = t38;
    t40 = (t29 + 4);
    t41 = *((unsigned int *)t29);
    t38 = (t38 & t41);
    t42 = *((unsigned int *)t40);
    t39 = (t39 & t42);
    t43 = (t37 + 4);
    t44 = *((unsigned int *)t37);
    *((unsigned int *)t37) = (t44 | t38);
    t45 = *((unsigned int *)t43);
    *((unsigned int *)t43) = (t45 | t39);
    xsi_driver_vfirst_trans(t33, 0, 15U);
    t46 = (t0 + 13552);
    *((int *)t46) = 1;

LAB1:    return;
LAB6:    t17 = (t0 + 12112U);
    *((char **)t17) = &&LAB4;
    goto LAB1;

}

static void NetDecl_204_9(char *t0)
{
    char t3[8];
    char t4[8];
    char t24[8];
    char t25[8];
    char *t1;
    char *t2;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;
    char *t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    unsigned int t50;
    unsigned int t51;
    char *t52;
    unsigned int t53;
    unsigned int t54;
    char *t55;
    unsigned int t56;
    unsigned int t57;
    char *t58;

LAB0:    t1 = (t0 + 12360U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(204, ng0);
    t2 = (t0 + 7456);
    t5 = (t2 + 56U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t7) != 0)
        goto LAB6;

LAB7:    t14 = (t4 + 4);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t14);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB8;

LAB9:    t20 = *((unsigned int *)t4);
    t21 = (~(t20));
    t22 = *((unsigned int *)t14);
    t23 = (t21 || t22);
    if (t23 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t14) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t24, 8);

LAB16:    t39 = (t0 + 13936);
    t46 = (t39 + 56U);
    t47 = *((char **)t46);
    t48 = (t47 + 56U);
    t49 = *((char **)t48);
    memset(t49, 0, 8);
    t50 = 65535U;
    t51 = t50;
    t52 = (t3 + 4);
    t53 = *((unsigned int *)t3);
    t50 = (t50 & t53);
    t54 = *((unsigned int *)t52);
    t51 = (t51 & t54);
    t55 = (t49 + 4);
    t56 = *((unsigned int *)t49);
    *((unsigned int *)t49) = (t56 | t50);
    t57 = *((unsigned int *)t55);
    *((unsigned int *)t55) = (t57 | t51);
    xsi_driver_vfirst_trans(t39, 0, 15U);
    t58 = (t0 + 13568);
    *((int *)t58) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t13 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t13) = 1;
    goto LAB7;

LAB8:    t18 = (t0 + 6576U);
    t19 = *((char **)t18);
    goto LAB9;

LAB10:    t18 = (t0 + 7616);
    t26 = (t18 + 56U);
    t27 = *((char **)t26);
    memset(t25, 0, 8);
    t28 = (t27 + 4);
    t29 = *((unsigned int *)t28);
    t30 = (~(t29));
    t31 = *((unsigned int *)t27);
    t32 = (t31 & t30);
    t33 = (t32 & 1U);
    if (t33 != 0)
        goto LAB17;

LAB18:    if (*((unsigned int *)t28) != 0)
        goto LAB19;

LAB20:    t35 = (t25 + 4);
    t36 = *((unsigned int *)t25);
    t37 = *((unsigned int *)t35);
    t38 = (t36 || t37);
    if (t38 > 0)
        goto LAB21;

LAB22:    t41 = *((unsigned int *)t25);
    t42 = (~(t41));
    t43 = *((unsigned int *)t35);
    t44 = (t42 || t43);
    if (t44 > 0)
        goto LAB23;

LAB24:    if (*((unsigned int *)t35) > 0)
        goto LAB25;

LAB26:    if (*((unsigned int *)t25) > 0)
        goto LAB27;

LAB28:    memcpy(t24, t45, 8);

LAB29:    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 16, t19, 16, t24, 16);
    goto LAB16;

LAB14:    memcpy(t3, t19, 8);
    goto LAB16;

LAB17:    *((unsigned int *)t25) = 1;
    goto LAB20;

LAB19:    t34 = (t25 + 4);
    *((unsigned int *)t25) = 1;
    *((unsigned int *)t34) = 1;
    goto LAB20;

LAB21:    t39 = (t0 + 5776U);
    t40 = *((char **)t39);
    goto LAB22;

LAB23:    t39 = (t0 + 4976U);
    t45 = *((char **)t39);
    goto LAB24;

LAB25:    xsi_vlog_unsigned_bit_combine(t24, 16, t40, 16, t45, 16);
    goto LAB29;

LAB27:    memcpy(t24, t40, 8);
    goto LAB29;

}

static void NetDecl_207_10(char *t0)
{
    char t3[8];
    char t4[8];
    char t23[8];
    char t24[8];
    char t37[8];
    char t47[8];
    char *t1;
    char *t2;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t25;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;
    char *t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    unsigned int t58;
    unsigned int t59;
    char *t60;
    unsigned int t61;
    unsigned int t62;
    char *t63;
    unsigned int t64;
    unsigned int t65;
    char *t66;

LAB0:    t1 = (t0 + 12608U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(207, ng0);
    t2 = (t0 + 7776);
    t5 = (t2 + 56U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t7) != 0)
        goto LAB6;

LAB7:    t14 = (t4 + 4);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t14);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB8;

LAB9:    t19 = *((unsigned int *)t4);
    t20 = (~(t19));
    t21 = *((unsigned int *)t14);
    t22 = (t20 || t21);
    if (t22 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t14) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t23, 8);

LAB16:    t53 = (t0 + 14000);
    t54 = (t53 + 56U);
    t55 = *((char **)t54);
    t56 = (t55 + 56U);
    t57 = *((char **)t56);
    memset(t57, 0, 8);
    t58 = 262143U;
    t59 = t58;
    t60 = (t3 + 4);
    t61 = *((unsigned int *)t3);
    t58 = (t58 & t61);
    t62 = *((unsigned int *)t60);
    t59 = (t59 & t62);
    t63 = (t57 + 4);
    t64 = *((unsigned int *)t57);
    *((unsigned int *)t57) = (t64 | t58);
    t65 = *((unsigned int *)t63);
    *((unsigned int *)t63) = (t65 | t59);
    xsi_driver_vfirst_trans(t53, 0, 17U);
    t66 = (t0 + 13584);
    *((int *)t66) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t13 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t13) = 1;
    goto LAB7;

LAB8:    t18 = ((char*)((ng6)));
    goto LAB9;

LAB10:    t25 = (t0 + 5136U);
    t26 = *((char **)t25);
    memset(t24, 0, 8);
    t25 = (t26 + 4);
    t27 = *((unsigned int *)t25);
    t28 = (~(t27));
    t29 = *((unsigned int *)t26);
    t30 = (t29 & t28);
    t31 = (t30 & 1U);
    if (t31 != 0)
        goto LAB17;

LAB18:    if (*((unsigned int *)t25) != 0)
        goto LAB19;

LAB20:    t33 = (t24 + 4);
    t34 = *((unsigned int *)t24);
    t35 = *((unsigned int *)t33);
    t36 = (t34 || t35);
    if (t36 > 0)
        goto LAB21;

LAB22:    t43 = *((unsigned int *)t24);
    t44 = (~(t43));
    t45 = *((unsigned int *)t33);
    t46 = (t44 || t45);
    if (t46 > 0)
        goto LAB23;

LAB24:    if (*((unsigned int *)t33) > 0)
        goto LAB25;

LAB26:    if (*((unsigned int *)t24) > 0)
        goto LAB27;

LAB28:    memcpy(t23, t47, 8);

LAB29:    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 32, t18, 32, t23, 32);
    goto LAB16;

LAB14:    memcpy(t3, t18, 8);
    goto LAB16;

LAB17:    *((unsigned int *)t24) = 1;
    goto LAB20;

LAB19:    t32 = (t24 + 4);
    *((unsigned int *)t24) = 1;
    *((unsigned int *)t32) = 1;
    goto LAB20;

LAB21:    t38 = (t0 + 8896);
    t39 = (t38 + 56U);
    t40 = *((char **)t39);
    t41 = ((char*)((ng6)));
    t42 = ((char*)((ng5)));
    xsi_vlogtype_concat(t37, 32, 18, 3U, t42, 16, t41, 1, t40, 1);
    goto LAB22;

LAB23:    t48 = (t0 + 6736U);
    t49 = *((char **)t48);
    t48 = (t0 + 8896);
    t50 = (t48 + 56U);
    t51 = *((char **)t50);
    t52 = ((char*)((ng6)));
    xsi_vlogtype_concat(t47, 32, 18, 3U, t52, 1, t51, 1, t49, 16);
    goto LAB24;

LAB25:    xsi_vlog_unsigned_bit_combine(t23, 32, t37, 32, t47, 32);
    goto LAB29;

LAB27:    memcpy(t23, t37, 8);
    goto LAB29;

}

static void Cont_215_11(char *t0)
{
    char t3[8];
    char t12[8];
    char t13[8];
    char t34[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    char *t38;
    char *t39;
    char *t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    unsigned int t53;
    unsigned int t54;
    char *t55;
    unsigned int t56;
    unsigned int t57;
    char *t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;

LAB0:    t1 = (t0 + 12856U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(215, ng0);
    t2 = (t0 + 6256U);
    t4 = *((char **)t2);
    memset(t3, 0, 8);
    t2 = (t3 + 4);
    t5 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 0);
    *((unsigned int *)t3) = t7;
    t8 = *((unsigned int *)t5);
    t9 = (t8 >> 0);
    *((unsigned int *)t2) = t9;
    t10 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t10 & 65535U);
    t11 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t11 & 65535U);
    t14 = (t0 + 8096);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memset(t13, 0, 8);
    t17 = (t16 + 4);
    t18 = *((unsigned int *)t17);
    t19 = (~(t18));
    t20 = *((unsigned int *)t16);
    t21 = (t20 & t19);
    t22 = (t21 & 1U);
    if (t22 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t17) != 0)
        goto LAB6;

LAB7:    t24 = (t13 + 4);
    t25 = *((unsigned int *)t13);
    t26 = *((unsigned int *)t24);
    t27 = (t25 || t26);
    if (t27 > 0)
        goto LAB8;

LAB9:    t30 = *((unsigned int *)t13);
    t31 = (~(t30));
    t32 = *((unsigned int *)t24);
    t33 = (t31 || t32);
    if (t33 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t24) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t13) > 0)
        goto LAB14;

LAB15:    memcpy(t12, t28, 8);

LAB16:    t35 = *((unsigned int *)t3);
    t36 = *((unsigned int *)t12);
    t37 = (t35 ^ t36);
    *((unsigned int *)t34) = t37;
    t38 = (t3 + 4);
    t39 = (t12 + 4);
    t40 = (t34 + 4);
    t41 = *((unsigned int *)t38);
    t42 = *((unsigned int *)t39);
    t43 = (t41 | t42);
    *((unsigned int *)t40) = t43;
    t44 = *((unsigned int *)t40);
    t45 = (t44 != 0);
    if (t45 == 1)
        goto LAB17;

LAB18:
LAB19:    t48 = (t0 + 14064);
    t49 = (t48 + 56U);
    t50 = *((char **)t49);
    t51 = (t50 + 56U);
    t52 = *((char **)t51);
    memset(t52, 0, 8);
    t53 = 65535U;
    t54 = t53;
    t55 = (t34 + 4);
    t56 = *((unsigned int *)t34);
    t53 = (t53 & t56);
    t57 = *((unsigned int *)t55);
    t54 = (t54 & t57);
    t58 = (t52 + 4);
    t59 = *((unsigned int *)t52);
    *((unsigned int *)t52) = (t59 | t53);
    t60 = *((unsigned int *)t58);
    *((unsigned int *)t58) = (t60 | t54);
    xsi_driver_vfirst_trans(t48, 0, 15);
    t61 = (t0 + 13600);
    *((int *)t61) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t13) = 1;
    goto LAB7;

LAB6:    t23 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t23) = 1;
    goto LAB7;

LAB8:    t28 = (t0 + 4976U);
    t29 = *((char **)t28);
    goto LAB9;

LAB10:    t28 = ((char*)((ng5)));
    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t12, 16, t29, 16, t28, 16);
    goto LAB16;

LAB14:    memcpy(t12, t29, 8);
    goto LAB16;

LAB17:    t46 = *((unsigned int *)t34);
    t47 = *((unsigned int *)t40);
    *((unsigned int *)t34) = (t46 | t47);
    goto LAB19;

}

static void Initial_233_12(char *t0)
{
    char *t1;
    char *t2;

LAB0:    xsi_set_current_line(234, ng0);

LAB2:    xsi_set_current_line(235, ng0);
    xsi_vlogfile_write(1, 0, 0, ng20, 1, t0);
    xsi_set_current_line(236, ng0);
    t1 = (t0 + 472);
    t2 = *((char **)t1);
    xsi_vlogfile_write(1, 0, 0, ng21, 2, t0, (char)119, t2, 32);
    xsi_set_current_line(237, ng0);
    t1 = (t0 + 608);
    t2 = *((char **)t1);
    xsi_vlogfile_write(1, 0, 0, ng22, 2, t0, (char)119, t2, 32);
    xsi_set_current_line(238, ng0);
    t1 = (t0 + 1152);
    t2 = *((char **)t1);
    xsi_vlogfile_write(1, 0, 0, ng23, 2, t0, (char)119, t2, 32);
    xsi_set_current_line(239, ng0);
    xsi_vlogfile_write(1, 0, 0, ng24, 1, t0);

LAB1:    return;
}


extern void work_m_01233936017743010701_1003833699_init()
{
	static char *pe[] = {(void *)Always_65_0,(void *)Always_87_1,(void *)Always_94_2,(void *)NetDecl_170_3,(void *)Cont_176_4,(void *)Always_181_5,(void *)Cont_187_6,(void *)Always_192_7,(void *)NetDecl_201_8,(void *)NetDecl_204_9,(void *)NetDecl_207_10,(void *)Cont_215_11,(void *)Initial_233_12};
	static char *se[] = {(void *)sp_reverse_bytes};
	xsi_register_didat("work_m_01233936017743010701_1003833699", "isim/openmsp430_test_isim_beh.exe.sim/work/m_01233936017743010701_1003833699.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
