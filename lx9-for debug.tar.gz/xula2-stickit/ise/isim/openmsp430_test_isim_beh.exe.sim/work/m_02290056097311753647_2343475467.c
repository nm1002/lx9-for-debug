/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/hp_guest/ti/xula2-stickit/ise/rtl/verilog/openmsp430/crypto/spongent_player.v";
static unsigned int ng1[] = {4294967295U, 4294967295U, 4294967295U, 4294967295U, 4294967295U, 4294967295U, 4294967295U, 4294967295U, 4294967295U, 4294967295U, 65535U, 65535U};
static int ng2[] = {175, 0};
static int ng3[] = {0, 0};
static int ng4[] = {1, 0};
static int ng5[] = {4, 0};



static void Always_39_0(char *t0)
{
    char t6[8];
    char t14[8];
    char t23[8];
    char t24[8];
    char t27[8];
    char t28[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    unsigned int t20;
    int t21;
    char *t22;
    char *t25;
    char *t26;
    char *t29;
    char *t30;

LAB0:    t1 = (t0 + 2816U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(39, ng0);
    t2 = (t0 + 3136);
    *((int *)t2) = 1;
    t3 = (t0 + 2848);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(39, ng0);

LAB5:    xsi_set_current_line(40, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t0 + 1584);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 176);
    xsi_set_current_line(43, ng0);
    t2 = (t0 + 1184U);
    t3 = *((char **)t2);
    memset(t6, 0, 8);
    t2 = (t6 + 4);
    t4 = (t3 + 40);
    t5 = (t3 + 44);
    t7 = *((unsigned int *)t4);
    t8 = (t7 >> 15);
    t9 = (t8 & 1);
    *((unsigned int *)t6) = t9;
    t10 = *((unsigned int *)t5);
    t11 = (t10 >> 15);
    t12 = (t11 & 1);
    *((unsigned int *)t2) = t12;
    t13 = (t0 + 1584);
    t15 = (t0 + 1584);
    t16 = (t15 + 72U);
    t17 = *((char **)t16);
    t18 = ((char*)((ng2)));
    xsi_vlog_generic_convert_bit_index(t14, t17, 2, t18, 32, 1);
    t19 = (t14 + 4);
    t20 = *((unsigned int *)t19);
    t21 = (!(t20));
    if (t21 == 1)
        goto LAB6;

LAB7:    xsi_set_current_line(46, ng0);
    xsi_set_current_line(46, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 1744);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);

LAB8:    t2 = (t0 + 1744);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 472);
    t13 = *((char **)t5);
    t5 = ((char*)((ng4)));
    memset(t6, 0, 8);
    xsi_vlog_signed_minus(t6, 32, t13, 32, t5, 32);
    memset(t14, 0, 8);
    xsi_vlog_signed_less(t14, 32, t4, 32, t6, 32);
    t15 = (t14 + 4);
    t7 = *((unsigned int *)t15);
    t8 = (~(t7));
    t9 = *((unsigned int *)t14);
    t10 = (t9 & t8);
    t11 = (t10 != 0);
    if (t11 > 0)
        goto LAB9;

LAB10:    goto LAB2;

LAB6:    xsi_vlogvar_assign_value(t13, t6, 0, *((unsigned int *)t14), 1);
    goto LAB7;

LAB9:    xsi_set_current_line(46, ng0);

LAB11:    xsi_set_current_line(48, ng0);
    t16 = (t0 + 1744);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    t19 = (t0 + 472);
    t22 = *((char **)t19);
    t19 = ((char*)((ng5)));
    memset(t23, 0, 8);
    xsi_vlog_signed_divide(t23, 32, t22, 32, t19, 32);
    memset(t24, 0, 8);
    xsi_vlog_signed_multiply(t24, 32, t18, 32, t23, 32);
    t25 = (t0 + 472);
    t26 = *((char **)t25);
    t25 = ((char*)((ng4)));
    memset(t27, 0, 8);
    xsi_vlog_signed_minus(t27, 32, t26, 32, t25, 32);
    memset(t28, 0, 8);
    xsi_vlog_signed_mod(t28, 32, t24, 32, t27, 32);
    t29 = (t0 + 1904);
    xsi_vlogvar_assign_value(t29, t28, 0, 0, 32);
    xsi_set_current_line(49, ng0);
    t2 = (t0 + 1184U);
    t3 = *((char **)t2);
    t2 = (t0 + 1144U);
    t4 = (t2 + 72U);
    t5 = *((char **)t4);
    t13 = (t0 + 1744);
    t15 = (t13 + 56U);
    t16 = *((char **)t15);
    xsi_vlog_generic_get_index_select_value(t6, 1, t3, t5, 2, t16, 32, 1);
    t17 = (t0 + 1584);
    t18 = (t0 + 1584);
    t19 = (t18 + 72U);
    t22 = *((char **)t19);
    t25 = (t0 + 1904);
    t26 = (t25 + 56U);
    t29 = *((char **)t26);
    xsi_vlog_generic_convert_bit_index(t14, t22, 2, t29, 32, 1);
    t30 = (t14 + 4);
    t7 = *((unsigned int *)t30);
    t21 = (!(t7));
    if (t21 == 1)
        goto LAB12;

LAB13:    xsi_set_current_line(46, ng0);
    t2 = (t0 + 1744);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t6, 0, 8);
    xsi_vlog_signed_add(t6, 32, t4, 32, t5, 32);
    t13 = (t0 + 1744);
    xsi_vlogvar_assign_value(t13, t6, 0, 0, 32);
    goto LAB8;

LAB12:    xsi_vlogvar_assign_value(t17, t6, 0, *((unsigned int *)t14), 1);
    goto LAB13;

}


extern void work_m_02290056097311753647_2343475467_init()
{
	static char *pe[] = {(void *)Always_39_0};
	xsi_register_didat("work_m_02290056097311753647_2343475467", "isim/openmsp430_test_isim_beh.exe.sim/work/m_02290056097311753647_2343475467.didat");
	xsi_register_executes(pe);
}
