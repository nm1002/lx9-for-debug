/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/hp_guest/ti/xula2-stickit/ise/rtl/verilog/openmsp430/crypto/spongent.v";
static const char *ng1 = "=== Spongent parameters ===";
static const char *ng2 = "Rate:       %3d";
static const char *ng3 = "State size: %3d";
static const char *ng4 = "===========================";



static void Initial_136_0(char *t0)
{
    char *t1;
    char *t2;

LAB0:    xsi_set_current_line(137, ng0);

LAB2:    xsi_set_current_line(138, ng0);
    xsi_vlogfile_write(1, 0, 0, ng1, 1, t0);
    xsi_set_current_line(139, ng0);
    t1 = (t0 + 608);
    t2 = *((char **)t1);
    xsi_vlogfile_write(1, 0, 0, ng2, 2, t0, (char)119, t2, 32);
    xsi_set_current_line(140, ng0);
    t1 = (t0 + 880);
    t2 = *((char **)t1);
    xsi_vlogfile_write(1, 0, 0, ng3, 2, t0, (char)119, t2, 32);
    xsi_set_current_line(141, ng0);
    xsi_vlogfile_write(1, 0, 0, ng4, 1, t0);

LAB1:    return;
}


extern void work_m_07788315536566117257_2777830972_init()
{
	static char *pe[] = {(void *)Initial_136_0};
	xsi_register_didat("work_m_07788315536566117257_2777830972", "isim/openmsp430_test_isim_beh.exe.sim/work/m_07788315536566117257_2777830972.didat");
	xsi_register_executes(pe);
}
